/* MED JITA optional, passwordless encrypted sync client.
 * Never sends the recovery code or a Craft URL to the remote service.
 * No network requests occur until a user presses a sync button.
 */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  if (!$('syncPane')) return;
  const CONFIG_KEY = 'med_jita_sync_config_v1';
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const cfg = {server:'',key:'',revision:0};
  try {
    const saved = JSON.parse(localStorage.getItem(CONFIG_KEY) || '{}');
    if (typeof saved.server === 'string') cfg.server = saved.server;
    if (typeof saved.key === 'string') cfg.key = saved.key;
    if (Number.isSafeInteger(saved.revision)) cfg.revision = Math.max(0,saved.revision);
  } catch (_) {}
  $('syncServer').value = cfg.server;
  $('syncRecovery').value = cfg.key;
  const show = (message, status='info') => {
    $('syncStatus').textContent = message;
    $('syncStatus').dataset.status = status;
  };
  function saveConfig() {
    cfg.server = $('syncServer').value.trim();
    cfg.key = $('syncRecovery').value.trim();
    try { localStorage.setItem(CONFIG_KEY, JSON.stringify(cfg)); }
    catch (_) { show('Sem espaço para salvar preferências. Guarde o código fora deste navegador.', 'error'); }
  }
  function requireServer() {
    const url = new URL(cfg.server);
    if (!/^https?:$/.test(url.protocol) || url.username || url.password || url.search || url.hash || url.pathname !== '/')
      throw Error('Informe somente a origem HTTPS da ponte, sem caminhos, usuário ou parâmetros.');
    if (url.protocol !== 'https:' && !['localhost','127.0.0.1','[::1]'].includes(url.hostname))
      throw Error('A ponte precisa usar HTTPS para proteger os dados.');
    return url.origin;
  }
  function bytesToB64url(bytes) {
    let str = '';
    for (let i=0; i<bytes.length; i+=8192) str += String.fromCharCode(...bytes.subarray(i,i+8192));
    return btoa(str).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
  }
  function b64urlToBytes(value) {
    if (!/^[A-Za-z0-9_-]+$/.test(value)) throw Error('Código de recuperação inválido.');
    const padded = value.replace(/-/g,'+').replace(/_/g,'/').padEnd(Math.ceil(value.length/4)*4,'=');
    return Uint8Array.from(atob(padded), c => c.charCodeAt(0));
  }
  async function sha(label, key) {
    if (!crypto?.subtle) throw Error('Criptografia indisponível. Abra o site publicado via HTTPS.');
    return new Uint8Array(await crypto.subtle.digest('SHA-256',encoder.encode(`med-jita:v1:${label}:${key}`)));
  }
  function validatedRecovery() {
    const key = cfg.key;
    if (key.length !== 43 || b64urlToBytes(key).length !== 32)
      throw Error('Gere ou cole um código de recuperação válido de 43 caracteres.');
    return key;
  }
  async function headers() {
    const bearer = bytesToB64url(await sha('auth',validatedRecovery()));
    return {Authorization:`Bearer ${bearer}`,'Content-Type':'application/json'};
  }
  async function request(path,options={}) {
    const response = await fetch(requireServer()+path,{cache:'no-store',...options});
    let payload = {};
    try { payload = await response.json(); } catch (_) {}
    if (!response.ok) {
      const error = new Error(typeof payload.error === 'string' ? payload.error : `Serviço respondeu HTTP ${response.status}.`);
      error.status = response.status;
      throw error;
    }
    return payload;
  }
  async function encrypt(backup) {
    const keyBytes = await sha('encryption',validatedRecovery());
    const aes = await crypto.subtle.importKey('raw',keyBytes,{name:'AES-GCM'},false,['encrypt']);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const plaintext = encoder.encode(JSON.stringify(backup));
    if (plaintext.length > 1000000) throw Error('Backup excede 1 MB. Exporte o JSON e reduza o histórico antes do envio.');
    const ciphertext = await crypto.subtle.encrypt({name:'AES-GCM',iv},aes,plaintext);
    return {alg:'AES-256-GCM',iv:bytesToB64url(iv),ciphertext:bytesToB64url(new Uint8Array(ciphertext))};
  }
  async function decrypt(envelope) {
    if (!envelope || envelope.alg !== 'AES-256-GCM') throw Error('Formato remoto incompatível.');
    const keyBytes = await sha('encryption',validatedRecovery());
    const aes = await crypto.subtle.importKey('raw',keyBytes,{name:'AES-GCM'},false,['decrypt']);
    const bytes = await crypto.subtle.decrypt({name:'AES-GCM',iv:b64urlToBytes(envelope.iv)},aes,b64urlToBytes(envelope.ciphertext));
    return JSON.parse(decoder.decode(bytes));
  }
  async function busy(button, fn) {
    button.disabled = true;
    try { await fn(); }
    catch (error) { show(error?.message || 'Não foi possível concluir a operação.', 'error'); }
    finally { button.disabled = false; }
  }
  for(const id of ['syncServer','syncRecovery']) $(id).addEventListener('change',() => {
    const before = cfg.server + '|' + cfg.key;
    saveConfig();
    if (before !== cfg.server+'|'+cfg.key) { cfg.revision=0;saveConfig(); }
  });
  $('syncCreateKey').addEventListener('click', () => {
    if (cfg.key && !confirm('Substituir a chave atual? Backups anteriores precisarão do código antigo.')) return;
    if (!crypto?.getRandomValues) { show('Abra a página por HTTPS para gerar uma chave segura.','error');return; }
    $('syncRecovery').value = bytesToB64url(crypto.getRandomValues(new Uint8Array(32)));
    cfg.revision=0;saveConfig();
    show('Código criado localmente. Guarde-o em local seguro antes de enviar qualquer backup.');
  });
  $('syncCopyKey').addEventListener('click',() => busy($('syncCopyKey'),async () => {
    validatedRecovery();await navigator.clipboard.writeText(cfg.key);
    show('Código copiado. Não o compartilhe publicamente.');
  }));
  $('syncTest').addEventListener('click', () => busy($('syncTest'),async () => {
    saveConfig();show('Verificando o serviço e a leitura do Craft…','working');
    const alive = await request('/api/health');
    if(!alive.ok) throw Error('O serviço não respondeu como uma ponte MED JITA.');
    const craft = await request('/api/craft/test',{headers:await headers()});
    show(craft.connected ? 'Ponte online. Craft conectado e leitura autorizada.'
      : 'Ponte online. Craft ainda não configurado no servidor. O backup cifrado continua disponível.', 'success');
  }));
  $('syncUpload').addEventListener('click', () => busy($('syncUpload'),async () => {
    saveConfig();
    if(!confirm('Enviar agora uma cópia cifrada de suas notas e histórico para a ponte configurada?')) return;
    show('Criptografando antes do envio…','working');
    const source = window.MED_JITA_BRIDGE?.exportBackup?.();
    if(!source) throw Error('A calculadora ainda não iniciou. Reabra a página.');
    const encrypted = await encrypt(source);
    const result = await request('/api/snapshot',{method:'PUT',headers:await headers(),body:JSON.stringify({revision:cfg.revision,payload:encrypted})});
    cfg.revision = result.revision;saveConfig();
    show('Backup cifrado recebido pelo servidor. Revisão '+cfg.revision+'. Nenhuma nota foi enviada ao Craft automaticamente.','success');
  }));
  $('syncDownload').addEventListener('click', () => busy($('syncDownload'),async () => {
    saveConfig();show('Buscando e decifrando seu backup…','working');
    const result = await request('/api/snapshot',{headers:await headers()});
    const restored = await decrypt(result.payload);
    if(!confirm('Restaurar backup remoto? O preenchimento atual será salvo no histórico, se houver notas.')) {
      show('Restauração cancelada. Seus dados locais não mudaram.'); return;
    }
    window.MED_JITA_BRIDGE?.importBackup?.(restored);
    cfg.revision = result.revision;saveConfig();
    show('Backup autenticado e restaurado. Atualização local concluída.','success');
  }));
})();
