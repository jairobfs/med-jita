# MED JITA · Arquitetura de persistência e Craft

## Situação desta versão

O MED JITA é um aplicativo estático de GitHub Pages. Funciona offline e guarda o preenchimento atual em `localStorage`, na chave `med_jita_state_v3`. Guarda até 60 versões nomeadas em `med_jita_history_v1`. O backup `MED_JITA_backup_com_historico.json` inclui ambos. Não é exigida conta.

**O Craft não está conectado como armazenamento de notas nesta versão.** Um protótipo de ponte está incluído em `backend/`: quando for implantado, só transmitirá backups após autorização explícita. O teste Craft é somente leitura e exige uma conexão privada configurada no servidor. Até lá, nenhuma nota é transmitida. Os dados locais podem ser perdidos por limpeza do navegador, modo privado, restrições de armazenamento ou troca de origem. Safari e web app instalado no iPhone não devem ser presumidos sincronizados.

## O que é tecnicamente possível

O Craft permite publicar documentos e também oferece API para ler/criar/atualizar documentos e Collections com permissões e escopo configuráveis. Isso possibilita usar uma Collection privada como *destino de registros* de uma aplicação externa.

Entretanto, **Craft não é um serviço de hospedagem de código de backend nem um banco de dados público multiusuário com autenticação de clientes pronta**. Publicação de páginas no Craft não substitui GitHub Pages para a calculadora interativa.

**Nunca incluir a URL de conexão, chave, senha ou token do Craft em HTML, JavaScript, repositório ou manifesto PWA públicos.** O endpoint de uma conexão contém credenciais que permitem acesso aos documentos autorizados. Restringir escopo e permissões no Craft.

## Arquitetura recomendada

1. **Agora:** GitHub Pages para interface e armazenamento local; cliente experimental de backup cifrado (sem login), servidor Worker e tabela D1 de snapshots com controle de revisão. Precisa ser implantado pelo proprietário.
2. **Prova de conexão Craft:** a rota `/api/craft/test` consulta `/connection` da API Craft com segredo guardado no Worker, devolvendo apenas sucesso/falha. A conexão HTTP real permanece pendente de configuração. Uma leitura de espaço por MCP já foi feita separadamente, mas não comprova a ponte HTTP.
3. **Integração pessoal futura:** após uma prova real de escrita e leitura da Full Space API, permitir arquivamento explícito em documento/Collection `MED JITA · Histórico`, com conexão de escopo restrito, validação do payload, quotas e consentimento claro.
4. **Caso o serviço seja usado por várias pessoas:** cada pessoa precisa ter registros isolados e uma forma segura de recuperar sua identidade (login, chave privada de recuperação ou equivalente). A chave aleatória gerada no aparelho pode ser transferida entre dispositivos, mas seu extravio é irrecuperável. Craft pode permanecer como CMS/arquivo pessoal, não como base única de identidades.

O cliente conversa somente com uma API de aplicação própria. A API **não** encaminha automaticamente cópias ao Craft; apenas testa conexão quando solicitado. O cliente cifra o JSON com AES-GCM, gera uma credencial de autorização separada e envia somente bytes opacos ao D1. O Worker usa checagem de origem, revisão monotônica e payload limitado. Antes de distribuição pública, definir política de quota/abuso e retenção. Não anunciar conexão Craft completa até realizar teste HTTP real de gravação, leitura e conflitos.

## Dados existentes compatíveis

- Esquema atual: `state.version = 3`.
- Áreas: `cfg`, `cab`, `tut`, `form`, `rea`, `ava`, com `theme` e `palette`.
- Cada versão: `id`, `name`, `savedAt`, `data` (estado v3).
- Importação de versões de backup 1, 2 e 3; backups v3 incluem `history`.
- Conflito remoto: a ponte usa revisão exata e responde 409 quando um dispositivo tentar sobrescrever estado mais recente. Mesclagem automática ainda não existe; é necessário recuperar a versão e salvar novo snapshot.

## Referências oficiais verificadas em 22/10/2026

- Craft API: https://support.craft.do/en/integrate/api
- Craft MCP Security: https://support.craft.do/en/integrate/mcp/security
- Craft MCP: https://support.craft.do/en/integrate/mcp

Essas páginas documentam conexões, escopo, permissões, documentos e Collections. Elas não equivalem a uma promessa de autenticação própria para usuários finais do MED JITA.
